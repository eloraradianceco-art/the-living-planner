# The Living Planner — v2.0 (Split Architecture)

## What Changed
The monolithic `App_Planner.jsx` (6,029 lines) has been split into a proper 
React project structure with lazy-loaded routes.

## Structure
```
src/
├── App.jsx                    # Routing only (73 lines)
├── main.jsx                   # Entry point
├── index.css                  # All styles
├── context/
│   └── PlannerContext.jsx     # AuthProvider + usePlannerData
├── hooks/
│   └── useResponsive.js       # useMediaQuery + useResponsive
├── services/
│   ├── supabase.js            # Supabase client
│   └── push.js                # Push notification service
├── utils/
│   ├── dates.js               # Date helpers
│   ├── scoring.js             # Life scores + progress
│   ├── insights.js            # Smart suggestions
│   ├── recurring.js           # Recurring task logic
│   └── storage.js             # localStorage helpers
├── components/
│   ├── Layout.jsx             # Nav + Layout wrapper
│   ├── QuickAddModal.jsx      # Quick add modal
│   ├── Charts.jsx             # MetricTile, MiniBarChart, etc
│   ├── ToastStack.jsx         # Toast notifications
│   ├── AppErrorBoundary.jsx   # Error boundary
│   ├── NotificationSettings.jsx
│   └── OnboardingChecklist.jsx
└── pages/
    ├── AuthPage.jsx
    ├── HomePage.jsx
    ├── TasksPage.jsx
    ├── CalendarPage.jsx
    ├── ProjectsPage.jsx
    ├── HabitsPage.jsx
    ├── GoalsPage.jsx
    ├── FinancePage.jsx        # 953 lines — largest page
    ├── HealthWellnessPage.jsx
    ├── ProductivityPage.jsx
    ├── LifestylePage.jsx
    ├── FaithPage.jsx
    ├── GrowthPage.jsx
    └── MorePage.jsx
```

## How to Deploy to Your Existing Vercel Project

### Option A — Replace files in your GitHub repo (Recommended)
1. In your GitHub repo, delete `src/App_Planner.jsx`
2. Upload all files from this zip maintaining the folder structure
3. Update `src/main.jsx` to import from `./App.jsx` instead of `./App_Planner.jsx`
4. Commit and push — Vercel auto-deploys

### Option B — Fresh repo
1. `npm install`
2. Copy your `.env` file (VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, etc)
3. `npm run dev` to test locally
4. Connect to Vercel

## Environment Variables (same as before)
```
VITE_SUPABASE_URL=
VITE_SUPABASE_ANON_KEY=
VITE_VAPID_PUBLIC_KEY=
VAPID_PRIVATE_KEY=
VAPID_EMAIL=
```

## What to Fix After Deploying
After the split, some import paths may need tweaking depending on how your 
current repo is structured. Check the browser console for any 
"Cannot find module" errors and adjust import paths accordingly.

The most likely issues to fix:
1. CSS variable names — verify all `var(--teal)` etc are in index.css
2. Any shared state between pages now goes through usePlannerData hook
3. Route paths — check all `<Link to="...">` match the routes in App.jsx
