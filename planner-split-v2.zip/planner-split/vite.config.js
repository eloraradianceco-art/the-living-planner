import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        // Chunk each page separately for optimal code splitting
        manualChunks: {
          'vendor':       ['react', 'react-dom', 'react-router-dom'],
          'supabase':     ['@supabase/supabase-js'],
          'finance':      ['./src/pages/FinancePage.jsx'],
          'wellness':     ['./src/pages/HealthWellnessPage.jsx'],
          'productivity': ['./src/pages/ProductivityPage.jsx'],
          'faith':        ['./src/pages/FaithPage.jsx'],
        },
      },
    },
  },
})
